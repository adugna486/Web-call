const localVideo = document.getElementById("localVideo");
const remoteVideo = document.getElementById("remoteVideo");
const statusEl = document.getElementById("status");
const startBtn = document.getElementById("startBtn");
const copyBtn = document.getElementById("copyBtn");
const leaveBtn = document.getElementById("leaveBtn");

const params = new URLSearchParams(location.search);
let room = params.get("room");
if (!room) {
  room = crypto.randomUUID().slice(0, 8);
  params.set("room", room);
  history.replaceState(null, "", `${location.pathname}?${params.toString()}`);
}
document.getElementById("roomLabel").textContent = `Room: ${room}`;

let socket, pc, localStream, pendingCandidates = [];
let started = false;
const rtcConfig = { iceServers: [{ urls: "stun:stun.l.google.com:19302" }] };

function status(text) { statusEl.textContent = text; }

async function start() {
  if (started) return;
  try {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    localVideo.srcObject = localStream;
    pc = new RTCPeerConnection(rtcConfig);
    localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
    pc.ontrack = event => { remoteVideo.srcObject = event.streams[0]; };
    pc.onicecandidate = event => {
      if (event.candidate) send({ type: "ice-candidate", candidate: event.candidate });
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "connected") status("Connected! You can talk now.");
      else if (["failed", "disconnected"].includes(pc.connectionState)) status("Connection interrupted. Try rejoining.");
    };

    const wsProtocol = location.protocol === "https:" ? "wss:" : "ws:";
    socket = new WebSocket(`${wsProtocol}//${location.host}/ws?room=${encodeURIComponent(room)}`);
    socket.onopen = () => status("Signaling connected. Waiting for the other person…");
    socket.onmessage = async event => {
      const msg = JSON.parse(event.data);
      try {
        if (msg.type === "room-full") { status("This room already has two people."); return; }
        if (msg.type === "peer-left") { status("The other person left the call."); remoteVideo.srcObject = null; return; }
        if (msg.type === "peer-joined") {
          status("Other person joined. Connecting…");
          if (socket._initiator) await createOffer();
          return;
        }
        if (msg.type === "joined") {
          socket._initiator = msg.initiator;
          if (msg.initiator) await createOffer();
          return;
        }
        if (msg.type === "offer") {
          await pc.setRemoteDescription(msg.sdp);
          await flushCandidates();
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          send({ type: "answer", sdp: pc.localDescription });
          return;
        }
        if (msg.type === "answer") {
          await pc.setRemoteDescription(msg.sdp);
          await flushCandidates();
          return;
        }
        if (msg.type === "ice-candidate" && msg.candidate) {
          if (pc.remoteDescription) await pc.addIceCandidate(msg.candidate);
          else pendingCandidates.push(msg.candidate);
        }
      } catch (err) { console.error(err); status("Could not complete connection. Please try again."); }
    };
    socket.onerror = () => status("Signaling error. Refresh and try again.");
    socket.onclose = () => { if (started) status("Signaling connection closed."); };
    started = true;
    startBtn.disabled = true;
    leaveBtn.disabled = false;
  } catch (err) {
    console.error(err);
    status("Camera/microphone permission is needed. Check browser permissions and try again.");
  }
}

async function createOffer() {
  if (!pc || pc.signalingState !== "stable") return;
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  send({ type: "offer", sdp: pc.localDescription });
}
function send(message) {
  if (socket && socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(message));
}
async function flushCandidates() {
  for (const candidate of pendingCandidates) await pc.addIceCandidate(candidate);
  pendingCandidates = [];
}
function leave() {
  started = false;
  if (socket) { socket.close(); socket = null; }
  if (pc) { pc.close(); pc = null; }
  if (localStream) { localStream.getTracks().forEach(t => t.stop()); localStream = null; }
  localVideo.srcObject = null;
  remoteVideo.srcObject = null;
  pendingCandidates = [];
  startBtn.disabled = false;
  leaveBtn.disabled = true;
  status("You left the call. You can join again.");
}
startBtn.addEventListener("click", start);
leaveBtn.addEventListener("click", leave);
copyBtn.addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(location.href); status("Room link copied."); }
  catch { status(`Copy this link: ${location.href}`); }
});
window.addEventListener("beforeunload", leave);
