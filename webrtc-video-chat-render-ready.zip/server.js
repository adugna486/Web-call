const express = require("express");
const http = require("http");
const { WebSocketServer, WebSocket } = require("ws");
const path = require("path");

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });
const rooms = new Map();

app.use(express.static(path.join(__dirname, "public")));
app.get("/healthz", (_req, res) => res.status(200).send("ok"));

wss.on("connection", (socket, req) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const room = (url.searchParams.get("room") || "").trim().slice(0, 100);
  if (!room) {
    socket.close(1008, "Room ID required");
    return;
  }

  let peers = rooms.get(room);
  if (!peers) {
    peers = new Set();
    rooms.set(room, peers);
  }
  if (peers.size >= 2) {
    socket.send(JSON.stringify({ type: "room-full" }));
    socket.close(1008, "Room is full");
    return;
  }

  peers.add(socket);
  socket.room = room;
  socket.send(JSON.stringify({ type: "joined", initiator: peers.size === 2 }));

  for (const peer of peers) {
    if (peer !== socket && peer.readyState === WebSocket.OPEN) {
      peer.send(JSON.stringify({ type: "peer-joined" }));
    }
  }

  socket.on("message", (raw) => {
    let message;
    try { message = JSON.parse(raw.toString()); } catch { return; }
    if (!["offer", "answer", "ice-candidate"].includes(message.type)) return;
    for (const peer of peers) {
      if (peer !== socket && peer.readyState === WebSocket.OPEN) {
        peer.send(JSON.stringify(message));
      }
    }
  });

  socket.on("close", () => {
    const roomPeers = rooms.get(room);
    if (!roomPeers) return;
    roomPeers.delete(socket);
    for (const peer of roomPeers) {
      if (peer.readyState === WebSocket.OPEN) {
        peer.send(JSON.stringify({ type: "peer-left" }));
      }
    }
    if (roomPeers.size === 0) rooms.delete(room);
  });
});

const port = process.env.PORT || 10000;
server.listen(port, "0.0.0.0", () => console.log(`Listening on ${port}`));
